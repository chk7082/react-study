import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      Hello React!
    </div>
  );
}

export default App;
